# backend-assessment-NodejsExpress
backend assessment for &lt;s>Hatchways&lt;/s>

### run these to use the webserver.

use ```npm install``` to install packages
use ```npm run start``` to run the server @ localhost on port 80 or standard http.

### testing

use ```npm run tests``` to run tests located @ \_\_test\_\_/ 


use ```npm run build``` to create build to deploy.



